// header.js
document.getElementById("header").innerHTML = `
  <header>
    <nav class="navbar">
      <div class="logo">Game Boy</div>
      <ul class="nav-links">
        <li><a href="index.html">Home</a></li>
        <li><a href="about.html">About</a></li>
        <li><a href="shop.html">Shop</a></li>
        <li><a href="contact.html">Contact</a></li>
      </ul>
    </nav>
  </header>
`;
