// footer.js
document.getElementById("footer").innerHTML = `
  <footer>
    <p>&copy; 2025 Nintendo Game Boy Retro Site. All rights reserved.</p>
  </footer>
`;
